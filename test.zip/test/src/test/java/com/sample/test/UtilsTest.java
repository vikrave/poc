package com.sample.test;

import static org.junit.Assert.fail;

import org.junit.Assert;
import org.junit.Test;

public class UtilsTest {

	@Test
	public void test() {
		//fail("Not yet implemented");
	}

	@Test
	public void reversDigitIsTrue() {
		Assert.assertEquals(12, Utils.reverseDigits(21));
	}
	
	@Test
	public void reverseDigitsNotZero() {
		Assert.assertEquals(0,Utils.reverseDigits(0));
	}
	
	@Test
	public void minimumNumber() {
		Assert.assertEquals(100,Utils.getMinimumNumber(3));
	}
	
	@Test
	public void maximumNumber() {
		Assert.assertEquals(999,Utils.getMaximumNumber(3));
	}
}
