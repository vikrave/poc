package com.sample.test;

import org.junit.Before;
import org.junit.Test;

import junit.framework.Assert;


import org.junit.After;

public class PaliondromeTest {
	
	 Paliondrome paliondrome = new Paliondrome();
	 
	
	@Before
	public void setUp() throws Exception{
		
	}
	
	@After
	public void tearDown() throws Exception{
		
	}
		
	@Test
	public void numberIsPaliondrome() {
		Assert.assertTrue(paliondrome.isPaliondrome(101));
	}
	
	
	

}
