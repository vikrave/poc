package com.sample.test;

public class Utils {
	
	public static int reverseDigits(int num) {
		int reverse = 0;
		while(num != 0) {
			int remainder = num % 10; // Remainder of the number
			reverse = reverse * 10 + remainder;
			num = num / 10;
		}
		
		return reverse;
		
	}

	public static int getMinimumNumber(int i) {
		//If digit is 2 minimum should be 10
		if(i != 0) {
			return (int) Math.pow(10,(i-1));
		}
		else
			return i;
	}
	
	public static int getMaximumNumber(int i) {
		//If digit is 2 minimum should be 99
		if(i != 0) {
			return (int) Math.pow(10,(i)) - 1;
		}
		else
			return i;
	}

}
