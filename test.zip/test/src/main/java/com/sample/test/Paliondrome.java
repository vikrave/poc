package com.sample.test;

public class Paliondrome {
	
	public void listPaliondrome(int digit) {
	 
		int min = Utils.getMinimumNumber(digit);
		int max = Utils.getMaximumNumber(digit);
		
		for(int i = min; i<= max ; i++) {
			if(isPaliondrome(i)) {
				System.out.println(i);
			}
		}
	}
	
	public boolean isPaliondrome(int number) {
	      int reversed = Utils.reverseDigits(number);
	      return number == reversed;
	 	
	}
	

}
